# Pastel Shop 🌸 - Flutter + REST API + MySQL (Docker)

CRUD produk yang **datanya tersimpan di database MySQL**, bukan lagi API mock DummyJSON.

```
┌────────────────┐  HTTP/JSON  ┌──────────────────────────────┐   SQL   ┌──────────────┐
│ Flutter (HP)   │ ──────────► │ Backend Node.js + Express    │ ──────► │ MySQL 8      │
│ Dio + Provider │  IP laptop  │ container "pastel_backend"   │         │ "pastel_mysql"│
└────────────────┘  :3000      └──────────────────────────────┘         └──────────────┘
                                         Docker Compose (satu perintah)
```

> **Video penjelasan & demo (YouTube, public):** https://youtu.be/ISI_LINK_VIDEO_KAMU

## Struktur proyek
```
pastel_shop/
├── docker-compose.yml          # MySQL + backend + phpMyAdmin
├── .env.example                # password/port database (opsional)
├── backend/
│   ├── Dockerfile
│   ├── package.json
│   ├── db/init.sql             # CREATE TABLE products + data awal
│   ├── src/app.js              # route CRUD (Create/Read/Update/Delete)
│   ├── src/server.js           # koneksi MySQL + start server
│   └── scripts/test_crud.js    # pengujian otomatis CRUD -> database
└── flutter_application_1/
    └── lib/
        ├── config/api_config.dart            # alamat IP server
        ├── services/api_service_products.dart# panggilan HTTP (Dio)
        ├── providers/product_provider.dart   # state + refresh dari database
        └── screens/ widgets/ models/ theme/  # UI pastel
```

## Pemetaan perintah dosen → implementasi

| # | Perintah dosen | Implementasi | File |
|---|---|---|---|
| 1 | Konfigurasi MySQL (menghubungkan database) | Tabel `products` dibuat otomatis saat container MySQL pertama kali jalan; backend memakai `mysql2` (connection pool) dan menunggu MySQL siap | `backend/db/init.sql`, `backend/src/server.js` |
| 2 | Docker Compose (menjalankan backend & database) | 3 service: `db` (mysql:8.0), `backend` (build dari Dockerfile), `phpmyadmin`; backend baru start setelah MySQL *healthy*; data disimpan di volume `db_data` | `docker-compose.yml`, `backend/Dockerfile` |
| 3 | Konfigurasi API (mengatur alamat IP komputer) | Satu tempat untuk mengatur IP: `ApiConfig.serverIp` (atau `--dart-define=API_BASE_URL=...`). Server membuka `0.0.0.0:3000` agar bisa diakses HP; Android diberi izin HTTP (`usesCleartextTraffic`) | `lib/config/api_config.dart`, `AndroidManifest.xml` |
| 4 | Koneksi aplikasi (Flutter ↔ API) | `Dio` memakai `baseUrl = ApiConfig.baseUrl`; error koneksi menampilkan pesan yang jelas + tombol "Coba lagi" | `lib/services/api_service_products.dart`, `lib/providers/product_provider.dart` |
| 5 | Read (menampilkan data dari database) | `GET /products`, `/products/{id}`, `/products/search?q=`, `/products/category/{slug}` → `SELECT` ke MySQL; grid, detail, search, filter kategori, sort, infinite scroll | `backend/src/app.js`, `list_product_screen.dart`, `detail_product_screen.dart` |
| 6 | Create (menambah data baru) | `POST /products` → `INSERT`, balasan 201 + id `AUTO_INCREMENT`; validasi di server | `add_product_screen.dart`, `app.js` |
| 7 | Update (mengedit data) | `PUT /products/{id}` → `UPDATE` | `edit_product_screen.dart`, `app.js` |
| 8 | Delete (menghapus data) | `DELETE /products/{id}` → `DELETE` (ada dialog konfirmasi) | `detail_product_screen.dart`, `app.js` |
| 9 | Pengujian (perubahan tersimpan di database) | Skrip otomatis + checklist manual + cek langsung lewat `mysql` / phpMyAdmin (lihat bagian *Pengujian*) | `backend/scripts/test_crud.js` |

---

## Cara menjalankan

### Prasyarat
Docker Desktop (atau Docker Engine + Compose v2), Flutter SDK, HP Android (USB debugging) atau emulator. Laptop dan HP harus **satu jaringan WiFi**.

### Langkah 1 – Jalankan database + backend (poin 1 & 2)
```bash
cd pastel_shop
docker compose up -d --build
docker compose ps          # db harus "healthy", backend "running"
docker compose logs -f backend
```
Log yang benar:
```
[db] terhubung ke MySQL db:3306/pastel_shop
[api] Pastel Shop API berjalan di http://0.0.0.0:3000
```
Cek di browser laptop: <http://localhost:3000/health> → `{"status":"ok","database":"connected"}` dan <http://localhost:3000/products>.
phpMyAdmin: <http://localhost:8080> (user `root`, password `rootpassword`).

> Ingin mengulang dari data awal? `docker compose down -v` lalu `docker compose up -d --build`
> (`init.sql` hanya dijalankan saat volume database masih kosong).

### Langkah 2 – Atur alamat IP (poin 3)
Cari IP laptop:

| OS | Perintah |
|---|---|
| Windows | `ipconfig` → **IPv4 Address** (mis. `192.168.1.10`) |
| macOS | `ipconfig getifaddr en0` |
| Linux | `hostname -I` |

Isi di `flutter_application_1/lib/config/api_config.dart`:
```dart
static const String serverIp = '192.168.1.10'; // <-- IP laptop kamu
```
Atau tanpa mengubah kode: `flutter run --dart-define=API_BASE_URL=http://192.168.1.10:3000`

| Perangkat | Alamat yang dipakai |
|---|---|
| HP fisik (satu WiFi) | IP laptop, mis. `192.168.1.10` |
| Emulator Android | `10.0.2.2` |
| Flutter Web / Windows desktop | `localhost` |

Tes dari **browser HP**: buka `http://192.168.1.10:3000/health`. Kalau tidak terbuka, izinkan port 3000 di firewall Windows (CMD sebagai Administrator):
```bat
netsh advfirewall firewall add rule name="PastelAPI" dir=in action=allow protocol=TCP localport=3000
```

### Langkah 3 – Jalankan aplikasi Flutter (poin 4)
```bash
cd flutter_application_1
flutter pub get
flutter devices
flutter run -d <id_hp>
```

---

## Endpoint API

| Operasi | Method & URL | Keterangan |
|---|---|---|
| Read (list) | `GET /products?limit=30&skip=0&sortBy=price&order=desc` | default urutan: produk terbaru di atas |
| Read (cari) | `GET /products/search?q=lipstick` | cari di title/brand/deskripsi/kategori |
| Read (kategori) | `GET /products/category-list`, `GET /products/category/{slug}` | |
| Read (detail) | `GET /products/{id}` | 404 jika tidak ada |
| Create | `POST /products` | body JSON: `title`*, `description`, `category`, `brand`, `price`, `discountPercentage`, `stock`, `thumbnail` → **201** |
| Update | `PUT /products/{id}` (atau `PATCH`) | field yang tidak dikirim tetap memakai nilai lama |
| Delete | `DELETE /products/{id}` | balasan memuat `isDeleted: true` |
| Cek koneksi DB | `GET /health` | |

Validasi: `title` wajib, `price ≥ 0`, `discountPercentage 0–100`, `stock` bilangan bulat `≥ 0` → jika salah, server membalas **400** dengan pesan yang tampil di aplikasi.

---

## Pengujian (poin 9)

### A. Otomatis (CRUD + bukti langsung di tabel MySQL)
```bash
docker compose exec backend node scripts/test_crud.js
```
Skrip melakukan Create → Read → Update → Delete lewat API, **dan** setiap langkah dicek langsung dengan `SELECT` ke tabel `products`. Hasil yang diharapkan:
```
HASIL: semua lulus, 0 gagal
```

### B. Manual dari aplikasi (untuk demo video)
Buka terminal kedua dan pantau database selagi memakai aplikasi:
```bash
docker compose exec db mysql -upastel -ppastel123 pastel_shop \
  -e "SELECT id,title,price,stock FROM products ORDER BY id DESC LIMIT 5;"
```

| Langkah di aplikasi | Yang harus terlihat di database |
|---|---|
| Buka aplikasi | daftar sama dengan isi tabel (`SELECT COUNT(*) FROM products;`) |
| Tombol **Tambah** → isi form → Simpan | baris baru muncul di `SELECT` (id bertambah) |
| Buka detail → ikon ✏️ → ubah harga/stok → Simpan | baris itu berubah (`SELECT ... WHERE id=...`) |
| Tutup aplikasi sepenuhnya & buka lagi | data **tetap ada** (bukan sekadar state di memori) |
| Detail → ikon 🗑️ → Hapus | baris hilang dari tabel |
| `docker compose restart` | data tetap ada (tersimpan di volume `db_data`) |

Bisa juga dilihat visual lewat phpMyAdmin → database `pastel_shop` → tabel `products`.

---

## Troubleshooting

| Gejala | Penyebab / solusi |
|---|---|
| Aplikasi: "Tidak bisa terhubung ke server" | IP di `api_config.dart` salah, HP beda WiFi, atau firewall memblokir port 3000. Tes `http://IP:3000/health` di browser HP. |
| Berjalan di emulator tapi gagal di HP | Emulator memakai `10.0.2.2`, HP fisik harus memakai IP laptop. |
| `docker compose up` error port 3000/3307/8080 terpakai | Ubah `API_PORT` / `DB_EXPOSE_PORT` di `.env` (salin dari `.env.example`). |
| Backend log "menunggu MySQL" terus | Lihat `docker compose logs db`; tunggu 20–40 dtk pada start pertama. |
| Tabel kosong / skema lama | `docker compose down -v` lalu `docker compose up -d --build`. |
| Gambar produk tidak muncul | Seed memakai gambar CDN DummyJSON (butuh internet); produk tanpa gambar menampilkan ikon pengganti. |
| iOS tidak bisa akses HTTP | Proyek ini ditujukan untuk Android; iOS butuh pengecualian ATS di `Info.plist`. |
